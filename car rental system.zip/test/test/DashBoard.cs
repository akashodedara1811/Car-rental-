﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace test
{
    public partial class DashBoard : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adr;
        DataTable dt;
        public DashBoard()
        {
            InitializeComponent();

            string connect = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;

            con = new SqlConnection(connect);
            con.Open();
            discust();
            discar();
            disavailale();
            disbooked();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
          //  gunaLinePanel1.BackColor = Color.FromArgb(10, 0, 0, 0);
        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
           
            manageCar mc = new manageCar();
            mc.Show();
            this.Hide();
        }

       

        private void gunaControlBox5_Click(object sender, EventArgs e)
        {
           // this.Close();
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            ManageCutomer cs = new ManageCutomer();
            cs.Show();

            this.Hide();
        }

        private void gunaAdvenceButton5_Click(object sender, EventArgs e)
        {
            RantCar rt = new RantCar();
            rt.Show();
            this.Hide();
        }

        private void gunaAdvenceButton6_Click(object sender, EventArgs e)
        {
            ManageReturn rs = new ManageReturn();
            rs.Show();
            this.Hide();
        }


        public void discar()
        {
            cmd = new SqlCommand("select model from manageCarsTbl", con);
            adr = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adr.Fill(dt);
            label5.Text = "" + dt.Rows.Count.ToString();
        }
        public void discust()
        {
            cmd = new SqlCommand("select name from managercustomer", con);
            adr = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adr.Fill(dt);
            label2.Text = "" + dt.Rows.Count.ToString();
        }
        public void disavailale()
        {
            cmd = new SqlCommand("select * from manageCarsTbl where status='Available'", con);
            adr = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adr.Fill(dt);
            label4.Text = "" + dt.Rows.Count.ToString();
        }
        public void disbooked()
        {
            cmd = new SqlCommand("select * from manageCarsTbl where status='Booked'", con);
            adr = new SqlDataAdapter(cmd);
            dt = new DataTable();
            adr.Fill(dt);
            label3.Text = "" + dt.Rows.Count.ToString();
        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            RantCar rt = new RantCar();
            rt.Show();
            this.Hide();
        }

        private void gunaAdvenceButton7_Click(object sender, EventArgs e)
        {
            login c2 = new login();
            c2.Show();
            this.Hide();
        }

        

       
        
    }
}
