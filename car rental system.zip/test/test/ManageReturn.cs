﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;
namespace test
{
    public partial class ManageReturn : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adr;
        public ManageReturn()
        {

            InitializeComponent();
            string connect = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
            con = new SqlConnection(connect);

           con.Open();
            display2();
            getreg();

            gunaDateTimePicker2.MinDate = DateTime.Now;
            gunaDateTimePicker2.MaxDate = DateTime.Now.AddDays(20);
            /*  comboBox2.Visible = true;*/
            gunaTextBox2.Visible = false;

        }

        private void ManageReturn_Load(object sender, EventArgs e)
        {

        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            DashBoard ds = new DashBoard();
            ds.Show();
            this.Close();
        }

        private void gunaAdvenceButton6_Click(object sender, EventArgs e)
        {

            this.Show();
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            manageCar ca = new manageCar();
            ca.Show();
            this.Close();
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            ManageCutomer cu = new ManageCutomer();
            cu.Show();
            this.Close();
        }

        private void gunaAdvenceButton5_Click(object sender, EventArgs e)
        {
            RantCar rt = new RantCar();
            rt.Show();
            this.Close();
        }


        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
           
            if (comboBox1.Text == "" || gunaTextBox1.Text == "" || textBox3.Text == "" || textBox4.Text == "" || gunaDateTimePicker2.Text == "")
            {
                DialogResult ds = MessageBox.Show("Please enter value....", "Warnning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                Regex r1 = new Regex(@"\d");
                bool checkdellay = r1.IsMatch(textBox3.Text);
                Regex r2 = new Regex(@"\d");
                bool checkfine = r2.IsMatch(textBox4.Text);
                if (checkdellay == false || checkfine == false)
                {
                    if (checkdellay == false)
                    {
                        DialogResult re = MessageBox.Show("Please enter valid value....", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox3.Focus();
                    }
                    else
                    {
                        DialogResult re = MessageBox.Show("Please enter valid value....", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textBox4.Focus();
                    }
                }
                else
                {
                    if (con.State == ConnectionState.Open)
                    {
                        cmd = new SqlCommand("insert into managereturn values ('" + comboBox1.Text + "','" + gunaTextBox1.Text + "','" + gunaDateTimePicker2.Text + "','" + Convert.ToInt16(textBox3.Text) + "','" + Convert.ToInt16(textBox4.Text) + "')", con);
                        int ans = cmd.ExecuteNonQuery();
                        if (ans > 0)
                        {
                            DialogResult de = MessageBox.Show("data added success fully....", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        cmd = new SqlCommand("update manageCarsTbl set status='Available' where Brand='" + comboBox1.Text + "'", con);
                        cmd.ExecuteNonQuery();
                        cmd = new SqlCommand("delete from managerantTbl where cname= '" + comboBox1.Text + "'", con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    else
                    {
                        con.Open();
                        cmd = new SqlCommand("insert into managereturn values ('" + comboBox1.Text + "','" + gunaTextBox1.Text + "','" + gunaDateTimePicker2.Text + "','" + Convert.ToInt16(textBox3.Text) + "','" + Convert.ToInt16(textBox4.Text) + "')", con);
                        int ans = cmd.ExecuteNonQuery();
                        if (ans > 0)
                        {
                            DialogResult de = MessageBox.Show("data added success fully....", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        cmd = new SqlCommand("update manageCarsTbl set status='Available' where Brand='" + comboBox1.Text + "'", con);
                        cmd.ExecuteNonQuery();
                        cmd = new SqlCommand("delete from managerantTbl where cname= '" + comboBox1.Text + "'", con);
                        cmd.ExecuteNonQuery();
                        
                    }
                   
                }

               
                display2();
                comboBox1.SelectedIndex = -1;
                textBox3.Text = "";
                textBox4.Text = "";
                gunaTextBox1.Text = "";
            }
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
                getreg();
               
            }
            else
            {
                getreg();
                con.Close();
            }
          

        }

        public void display2()
        {
           
            cmd = new SqlCommand("select * from managereturn", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            gunaDataGridView1.RowTemplate.Height = 40;
            gunaDataGridView1.DataSource = dt;
            gunaDataGridView1.Columns["Id"].HeaderText = "ID Number";
            gunaDataGridView1.Columns["carname"].HeaderText = "Car Name ";
            gunaDataGridView1.Columns["cusname"].HeaderText = "Customer Name ";
            gunaDataGridView1.Columns["rdate"].HeaderText = "Return Car Date";
            gunaDataGridView1.Columns["delay"].HeaderText = "Delay ";
            gunaDataGridView1.Columns["fine"].HeaderText = "Fine";
        }
        public void getreg()
        {

            cmd = new SqlCommand("select * from manageCarsTbl where status='Booked'", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "id";
            comboBox1.DisplayMember = "Brand";
            con.Close();
           
        }
      

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
                get();
            }
            else
            {
                get();
                con.Close();
            }
            
        
        

        }
    public void get()
        {
            cmd = new SqlCommand("select * from managerantTbl where cname='" + comboBox1.Text + "'", con);

            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                gunaTextBox1.Text = dr["cuname"].ToString();
            }
}

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            gunaTextBox2.Visible = true;
            comboBox1.Hide();
            //textBox1.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            gunaTextBox2.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            gunaTextBox1.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            gunaDateTimePicker2.Value = DateTime.Now;
            textBox3.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox4.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
          
        }

        private void gunaAdvenceButton8_Click(object sender, EventArgs e)
        {
            
            if (gunaTextBox2.Text == "" || gunaTextBox1.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                DialogResult de = MessageBox.Show("Please enter value....", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (con.State == ConnectionState.Open)
                {
                    cmd = new SqlCommand("delete from managereturn", con);
                    int ans = cmd.ExecuteNonQuery();
                    if (ans > 0)
                    {
                        DialogResult de = MessageBox.Show("Data Delete success fully....", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    con.Close();
                   
                }
                else
                {
                    con.Open();
                    cmd = new SqlCommand("delete from managereturn where carname='"+gunaTextBox2.Text+"'", con);
                    int ans = cmd.ExecuteNonQuery();
                    if (ans > 0)
                    {
                        DialogResult de = MessageBox.Show("Data Delete success fully....", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
               
            }
            display2();
            gunaTextBox2.Text = "";
            gunaTextBox2.Visible = false;
            comboBox1.Visible = true;
            gunaTextBox1.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            gunaDateTimePicker2.Text = "";
        }

        private void gunaAdvenceButton7_Click(object sender, EventArgs e)
        {
          
            if (gunaTextBox1.Text == "" || gunaDateTimePicker2.Text == "" || gunaTextBox2.Text == "" || textBox3.Text == "" || textBox4.Text=="")
            {
                DialogResult de = MessageBox.Show("Please enter value....", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                
                cmd = new SqlCommand("select * from managerantTbl where cuname='" + comboBox1.Text + "'", con);
                adr = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adr.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    DialogResult de = MessageBox.Show("this data allredy inserted...", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    Regex r1 = new Regex(@"^(\d)*$");
                    bool check = r1.IsMatch(textBox3.Text);
                    Regex r2 = new Regex(@"^(\d)*$");
                    bool check1 = r2.IsMatch(textBox4.Text);
                    if (check == false)
                    {
                        DialogResult de = MessageBox.Show("please enter valid number...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                       
                    }
                    
                    else  if (check1 == false)
                    {
                        DialogResult de = MessageBox.Show("please enter valid number...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    else
                    {
                        if (con.State == ConnectionState.Closed)
                        {
                            con.Open();
                            cmd = new SqlCommand("update managereturn set rdate='" + gunaDateTimePicker2.Text + "', delay='" + textBox3.Text + "', fine='" + textBox4.Text + "' where carname='" + gunaTextBox2.Text + "'", con);
                            int ans = cmd.ExecuteNonQuery();
                            if (ans > 0)
                            {
                                DialogResult de = MessageBox.Show("Data updated success fully...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            cmd = new SqlCommand("update managereturn set rdate='" + gunaDateTimePicker2.Text + "', delay='" + textBox3.Text + "', fine='" + textBox4.Text + "' where carname='" + gunaTextBox2.Text + "'", con);
                            int ans = cmd.ExecuteNonQuery();
                            if (ans > 0)
                            {
                                DialogResult de = MessageBox.Show("Data updated success fully...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            con.Close();
                        }
                       
                       
                    }
                }
            }
            display2();

            gunaTextBox2.Text = "";
            gunaTextBox2.Visible = false;
            comboBox1.Visible = true;
            gunaTextBox1.Text = "";
            textBox3.Text = "";
            textBox4.Text = ""; 
            gunaDateTimePicker2.Text = "";
        }

        private void gunaDateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void gunaAdvenceButton9_Click(object sender, EventArgs e)
        {
            DialogResult rs = MessageBox.Show("Are you sure to Refresh the data?", "Refresh information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            gunaTextBox2.Text = "";
            gunaTextBox2.Visible = false;
            comboBox1.Visible = true;
            gunaTextBox1.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            gunaDateTimePicker2.Text="";

        }

        private void gunaAdvenceButton10_Click(object sender, EventArgs e)
        {
            login c2 = new login();
            c2.Show();
            this.Hide();
        }

       
    }
}
