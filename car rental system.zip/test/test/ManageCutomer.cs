﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;

namespace test
{
    public partial class ManageCutomer : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adr;
        public ManageCutomer()
        {
            InitializeComponent();
            string connect = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
            con = new SqlConnection(connect);
            con.Open();
            dis();
            
            textBox1.Visible = false;
        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            DashBoard ds = new DashBoard();
            ds.Show();
            this.Close();
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            manageCar cs = new manageCar();
            cs.Show();
            this.Close();
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void gunaAdvenceButton5_Click(object sender, EventArgs e)
        {
            RantCar rsa = new RantCar();
            rsa.Show();
            this.Close();
        }

        private void gunaAdvenceButton6_Click(object sender, EventArgs e)
        {
            ManageReturn re = new ManageReturn();
            re.Show();
            this.Close();
        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                DialogResult re = MessageBox.Show("Please enter value...", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
            cmd = new SqlCommand("select * from managercustomer where name='" + textBox2.Text + "'", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DialogResult re = MessageBox.Show("this data all ready inserted..", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                Regex r1 = new Regex(@"^+[a-zA-z][a-zA-z\s]+$");
                bool checknm = r1.IsMatch(textBox2.Text);
                Regex r2 = new Regex(@"^\d{10}$");
                bool checknum = r2.IsMatch(textBox4.Text);
                if (checknm == false || checknum == false)
                {
                    if (checknm == false)
                    {
                        DialogResult rs = MessageBox.Show("Please enter text only", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox2.Focus();
                    }
                    else if (checknum == false || Convert.ToInt16(r2) >= 10)
                    {
                        DialogResult rs = MessageBox.Show("Please enter 10 number only", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox4.Focus();
                    }
                }
                else
                {
                   

                        cmd = new SqlCommand("insert into managercustomer values('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')", con);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {
                            DialogResult re = MessageBox.Show("data success fully inserted..", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";

                    }
                }
            }
            dis();
            
        }

        public void dis()
        {
            cmd = new SqlCommand("select * from managercustomer", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            gunaDataGridView1.RowTemplate.Height = 40;
            gunaDataGridView1.DataSource = dt;
            gunaDataGridView1.Columns["Id"].HeaderText = "Id Number";
            gunaDataGridView1.Columns["name"].HeaderText = "Customer Name";
            gunaDataGridView1.Columns["address"].HeaderText = "Customer Address";
            gunaDataGridView1.Columns["Phone"].HeaderText = "Customer Number";
        }

        private void gunaAdvenceButton7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                DialogResult re = MessageBox.Show("Please enter value...", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
            Regex r1 = new Regex(@"^+[a-zA-z][a-zA-z\s]+$");
            bool checknm = r1.IsMatch(textBox2.Text);
            Regex r2 = new Regex(@"\d{10}");
            bool checknum = r2.IsMatch(textBox4.Text);
            if (checknm == false || checknum == false)
            {
                if (checknm == false)
                {
                    DialogResult rs = MessageBox.Show("Please enter text only", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox2.Focus();
                }
                else if (checknum == false)
                {
                    DialogResult rs = MessageBox.Show("Please enter 10 number only", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox4.Focus();
                }
            }
            else
            {
               
                    cmd = new SqlCommand("update managercustomer set name='" + textBox2.Text + "',address='" + textBox3.Text + "',phone='" + textBox4.Text + "' where id='" + textBox1.Text + "'", con);
                    int a = cmd.ExecuteNonQuery();
                    if (a > 0)
                    {
                        DialogResult re = MessageBox.Show("data success fully updated..", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";

                }
            }
            dis();
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Visible = false;
            textBox1.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox2.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox3.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox4.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
        }

        private void gunaAdvenceButton8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                DialogResult re = MessageBox.Show("Please enter value...", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cmd = new SqlCommand("delete from managercustomer  where id='" + textBox1.Text + "'", con);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    DialogResult re = MessageBox.Show("data success fully deleted..", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";

            }
        }

        private void gunaAdvenceButton9_Click(object sender, EventArgs e)
        {
            DialogResult rs = MessageBox.Show("Are you sure to Refresh the data?", "Refresh information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
            textBox1.Text = "";
         
            textBox1.Visible = false;
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void gunaAdvenceButton11_Click(object sender, EventArgs e)
        {
            login c2 = new login();
            c2.Show();
            this.Hide();
        }

        
    }
}
